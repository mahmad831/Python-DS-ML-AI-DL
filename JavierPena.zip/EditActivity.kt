import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_edit_journal.*
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.*

class EditJournalActivity : AppCompatActivity() {

    private var selectedDay: String? = null
    private var selectedTime: LocalTime? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_journal)

        // get the selected day from the intent
        selectedDay = intent.getStringExtra("selectedDay")
        if (selectedDay != null) {
            // if the selected day is not null, set the title to "Edit Day"
            title = getString(R.string.edit_day)
            // set the day text view to the selected day
            dayTextView.text = selectedDay
        } else {
            // if the selected day is null, set the title to "Add Day"
            title = getString(R.string.add_day)
        }

        // set the time edit text to the current time
        selectedTime = LocalTime.now()
        timeEditText.setText(selectedTime?.format(DateTimeFormatter.ofPattern("hh:mm a")))
    }

    fun selectTime(view: View) {
        // show a time picker dialog to select the time
        val timePickerDialog = TimePickerFragment(selectedTime)
        timePickerDialog.setOnTimeSetListener { _, hourOfDay, minute ->
            // set the selected time to the edit text
            selectedTime = LocalTime.of(hourOfDay, minute)
            timeEditText.setText(selectedTime?.format(DateTimeFormatter.ofPattern("hh:mm a")))
        }
        timePickerDialog.show(supportFragmentManager, "timePicker")
    }

    fun saveDay(view: View) {
        // get the day and time entered by the user
        val day = dayTextView.text.toString()
        val time = selectedTime?.format(DateTimeFormatter.ofPattern("hh:mm a"))

        if (day.isNotEmpty() && time != null) {
            // if the day and time are not empty, save the day to the database
            val journal = Journal(day, time, activitiesEditText.text.toString())
            JournalDatabase.getInstance(this).journalDao().insert(journal)
            Toast.makeText(this, R.string.day_saved, Toast.LENGTH_SHORT).show()

            // go back to the home page
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        } else {
            // if the day or time is empty, show an error message
            Toast.makeText(this, R.string.fill_all_fields, Toast.LENGTH_SHORT).show()
        }
    }

    fun cancelEdit(view: View) {
        // go back to the previous activity
        finish()
    }
}
