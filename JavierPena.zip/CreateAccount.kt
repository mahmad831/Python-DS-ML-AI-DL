import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CreateAccountActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)

        val etName = findViewById<EditText>(R.id.et_name)
        val etEmail = findViewById<EditText>(R.id.et_email)
        val etPassword = findViewById<EditText>(R.id.et_password)
        val btnCreateAccount = findViewById<Button>(R.id.btn_create_account)
        val btnBackToLogin = findViewById<Button>(R.id.btn_back_to_login)

        btnCreateAccount.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Fill all the fields to create your account", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$".toRegex()
            if (!password.matches(passwordPattern)) {
                Toast.makeText(this, "Your password must be of 8 characters with upper case and lower case characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // TODO: create the account
        }

        btnBackToLogin.setOnClickListener {
            finish()
        }
    }
}
