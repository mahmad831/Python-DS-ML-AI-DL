import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Display today's schedule
        val tvTodaySchedule = findViewById<TextView>(R.id.tv_today_schedule)
        tvTodaySchedule.text = "Today's Schedule: ${getTodaySchedule()}"

        // Allow user to add or change activities by clicking within the box
        val activitiesListLayout = findViewById<LinearLayout>(R.id.ll_activities_list)
        activitiesListLayout.setOnClickListener {
            // TODO: implement logic to bring user to "Your Journal" page
        }

        // Add scroll down function on the right side of the box
        val activitiesScrollView = findViewById<ScrollView>(R.id.sv_activities)
        activitiesScrollView.setOnTouchListener { view, event ->
            // TODO: implement scroll down functionality
            false
        }

        // Implement quick note functionality with save button
        val quickNoteEditText = findViewById<EditText>(R.id.et_quick_note)
        val saveNoteButton = findViewById<Button>(R.id.btn_save_note)
        saveNoteButton.setOnClickListener {
            val note = quickNoteEditText.text.toString()
            saveNoteToDatabase(note)
            quickNoteEditText.text.clear()
            Snackbar.make(findViewById(android.R.id.content), "Note saved!", Snackbar.LENGTH_SHORT).show()
        }

        // Add floating button for more functions
        val moreOptionsFab = findViewById<FloatingActionButton>(R.id.fab_more_options)
        moreOptionsFab.setOnClickListener {
            val popupMenu = PopupMenu(this, moreOptionsFab)
            popupMenu.menuInflater.inflate(R.menu.menu_home, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { menuItem: MenuItem ->
                when (menuItem.itemId) {
                    R.id.menu_item_settings -> {
                        // TODO: implement settings functionality
                        Snackbar.make(findViewById(android.R.id.content), "Settings clicked!", Snackbar.LENGTH_SHORT).show()
                        true
                    }
                    R.id.menu_item_logout -> {
                        startActivity(Intent(this, WelcomeActivity::class.java))
                        finish()
                        true
                    }
                    else -> false
                }
            }
            popupMenu.show()
        }
    }

    private fun getTodaySchedule(): String {
        // TODO: implement logic to retrieve today's schedule from database
        return "No activities scheduled for today"
    }

    private fun saveNoteToDatabase(note: String) {
        // TODO: implement logic to save note to database
    }
}
