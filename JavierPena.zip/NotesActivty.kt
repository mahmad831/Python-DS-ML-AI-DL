class NotesActivity : AppCompatActivity() {
    
    private lateinit var notesList: RecyclerView
    private lateinit var newNoteEditText: EditText
    private lateinit var addNoteButton: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)
        
        // initialize UI components
        notesList = findViewById(R.id.notes_list)
        newNoteEditText = findViewById(R.id.new_note_edittext)
        addNoteButton = findViewById(R.id.add_note_button)
        
        // setup recyclerview
        notesList.layoutManager = LinearLayoutManager(this)
        notesList.adapter = NotesAdapter()
        
        // setup add note button
        addNoteButton.setOnClickListener {
            val newNote = newNoteEditText.text.toString().trim()
            if (newNote.isNotEmpty()) {
                // add new note to database or local storage
                // for simplicity, we will just add it to the adapter
                (notesList.adapter as NotesAdapter).addNewNote(newNote)
                
                // clear edittext
                newNoteEditText.text.clear()
            }
        }
    }
}

class NotesAdapter : RecyclerView.Adapter<NotesAdapter.ViewHolder>() {
    
    private val notes = mutableListOf<Pair<String, String>>()
    
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val noteTextView: TextView = itemView.findViewById(R.id.note_textview)
        private val dateTextView: TextView = itemView.findViewById(R.id.date_textview)
        
        fun bind(note: Pair<String, String>) {
            noteTextView.text = note.first
            dateTextView.text = note.second
        }
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.notes_list_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(notes[position])
    }

    override fun getItemCount(): Int {
        return notes.size
    }
    
    fun addNewNote(note: String) {
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        notes.add(0, Pair(note, date))
        notifyItemInserted(0)
    }
}
