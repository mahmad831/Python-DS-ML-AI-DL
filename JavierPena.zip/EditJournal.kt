class EditJournalActivity : AppCompatActivity() {

    private var currentDay: LocalDate? = null
    private lateinit var adapter: ActivityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_journal)

        val intent = intent
        currentDay = intent.getSerializableExtra("currentDay") as LocalDate?

        supportActionBar?.title = currentDay?.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))

        adapter = ActivityAdapter(this, currentDay)
        activityListView.adapter = adapter

        addActivityButton.setOnClickListener {
            val dialog = Dialog(this)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(true)
            dialog.setContentView(R.layout.dialog_add_activity)

            val activityNameEditText = dialog.findViewById<EditText>(R.id.activityNameEditText)
            val startTimeEditText = dialog.findViewById<EditText>(R.id.startTimeEditText)
            val endTimeEditText = dialog.findViewById<EditText>(R.id.endTimeEditText)
            val addButton = dialog.findViewById<Button>(R.id.addButton)

            addButton.setOnClickListener {
                val activityName = activityNameEditText.text.toString().trim()
                val startTime = LocalTime.parse(startTimeEditText.text.toString(), DateTimeFormatter.ofPattern("h:mm a"))
                val endTime = LocalTime.parse(endTimeEditText.text.toString(), DateTimeFormatter.ofPattern("h:mm a"))

                if (activityName.isNotEmpty()) {
                    adapter.addActivity(Activity(activityName, startTime, endTime))
                    dialog.dismiss()
                } else {
                    Toast.makeText(this, "Please enter a valid activity name", Toast.LENGTH_SHORT).show()
                }
            }

            dialog.show()
        }

        activityListView.setOnItemClickListener { _, _, position, _ ->
            val dialog = Dialog(this)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(true)
            dialog.setContentView(R.layout.dialog_edit_activity)

            val activity = adapter.getItem(position)

            val activityNameEditText = dialog.findViewById<EditText>(R.id.activityNameEditText)
            val startTimeEditText = dialog.findViewById<EditText>(R.id.startTimeEditText)
            val endTimeEditText = dialog.findViewById<EditText>(R.id.endTimeEditText)
            val updateButton = dialog.findViewById<Button>(R.id.updateButton)
            val deleteButton = dialog.findViewById<Button>(R.id.deleteButton)

            activityNameEditText.setText(activity.name)
            startTimeEditText.setText(activity.startTime.format(DateTimeFormatter.ofPattern("h:mm a")))
            endTimeEditText.setText(activity.endTime.format(DateTimeFormatter.ofPattern("h:mm a")))

            updateButton.setOnClickListener {
                val activityName = activityNameEditText.text.toString().trim()
                val startTime = LocalTime.parse(startTimeEditText.text.toString(), DateTimeFormatter.ofPattern("h:mm a"))
                val endTime = LocalTime.parse(endTimeEditText.text.toString(), DateTimeFormatter.ofPattern("h:mm a"))

                if (activityName.isNotEmpty()) {
                    adapter.updateActivity(position, Activity(activityName, startTime, endTime))
                    dialog.dismiss()
                } else {
                    Toast.makeText(this, "Please enter a valid activity name", Toast.LENGTH_SHORT).show()
                }
            }

            deleteButton.setOnClickListener {
                adapter.deleteActivity(position)
                dialog.dismiss()
            }

            dialog.show()
        }
    }
}
