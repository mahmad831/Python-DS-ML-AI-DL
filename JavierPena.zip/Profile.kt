import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        passwordEditText = findViewById(R.id.password_edittext)

        // Set up Save button click listener
        val saveButton = findViewById<Button>(R.id.save_button)
        saveButton.setOnClickListener {
            saveProfileChanges()
        }
    }

    private fun saveProfileChanges() {
        // Get user input
        val password = passwordEditText.text.toString()

        // Validate password
        if (!isValidPassword(password)) {
            // Show error message if password is invalid
            passwordEditText.error = "Your password must be of 8 characters with upper case and lower case characters."
        } else {
            // Save changes to the database
            // ...
            // Show success message
            Toast.makeText(this, "Changes saved successfully", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isValidPassword(password: String): Boolean {
        val regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$"
        return regex.toRegex().matches(password)
    }
}
