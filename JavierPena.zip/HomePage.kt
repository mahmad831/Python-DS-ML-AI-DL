import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Display today's schedule
        val tvTodaySchedule = findViewById<TextView>(R.id.tv_today_schedule)
        tvTodaySchedule.text = "Today's Schedule: ${getTodaySchedule()}"

        // Allow user to add or change activities by clicking within the box
        val activitiesListLayout = findViewById<LinearLayout>(R.id.ll_activities_list)
        activitiesListLayout.setOnClickListener {
            // TODO: implement logic to bring user to "Your Journal" page
        }

        // Add scroll down function on the right side of the box
        val activitiesScrollView = findViewById<ScrollView>(R.id.sv_activities)
        activitiesScrollView.setOnTouchListener { view, event ->
            // TODO: implement scroll down functionality
            false
        }

        // Implement quick note functionality with save button
        val quickNoteEditText = findViewById<EditText>(R.id.et_quick_note)
        val saveNoteButton = findViewById<Button>(R.id.btn_save_note)
        saveNoteButton.setOnClickListener {
            val note = quickNoteEditText.text.toString()
            saveNoteToDatabase(note)
            quickNoteEditText.text.clear()
            // TODO: display toast or confirmation message to user
        }

        // Add floating button for more functions
        val moreOptionsFab = findViewById<FloatingActionButton>(R.id.fab_more_options)
        moreOptionsFab.setOnClickListener {
            // TODO: implement more options menu
        }
    }

    private fun getTodaySchedule(): String {
        // TODO: implement logic to retrieve today's schedule from database
        return "No activities scheduled for today"
    }

    private fun saveNoteToDatabase(note: String) {
        // TODO: implement logic to save note to database
    }
}
